#pragma once
// ================================================
//  Memory.h — Класс для работы с памятью игры
//  Bowmasters ARM64 | Yrener Soft
//  УРОК: Читаем и пишем в память процесса
// ================================================

#include <cstdint>
#include <cstdio>
#include <cstring>
#include <android/log.h>

#define TAG "YrenerSoft"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

class Memory {
public:

    // --------------------------------------------------
    // getLibBase — находит базовый адрес .so библиотеки
    // УРОК: Каждый раз при запуске игры .so грузится
    //       по разному адресу. Нам нужен этот адрес
    //       чтобы вычислить реальный адрес функции:
    //       реальный_адрес = base + offset
    // --------------------------------------------------
    static uintptr_t getLibBase(const char* libName) {
        FILE* maps = fopen("/proc/self/maps", "r");
        if (!maps) {
            LOGE("Не удалось открыть /proc/self/maps");
            return 0;
        }

        char line[512];
        uintptr_t base = 0;

        while (fgets(line, sizeof(line), maps)) {
            if (strstr(line, libName)) {
                // Строка выглядит так:
                // "7f1234000-7f1240000 r-xp ... libil2cpp.so"
                // Берём первое число — это и есть базовый адрес
                base = (uintptr_t)strtoull(line, nullptr, 16);
                break;
            }
        }

        fclose(maps);

        if (base)
            LOGI("[+] %s загружен по адресу: 0x%lX", libName, base);
        else
            LOGE("[-] %s не найден в памяти!", libName);

        return base;
    }

    // --------------------------------------------------
    // writeBytes — записывает байты по адресу
    // УРОК: Используется для патча инструкций ARM64
    //       Например заменяем "CBZ" (прыжок если 0)
    //       на "NOP" (ничего не делать) — отключаем проверку
    // --------------------------------------------------
    static bool writeBytes(uintptr_t address, const char* bytes, size_t size) {
        if (!address) return false;

        // Копируем байты в память
        memcpy((void*)address, bytes, size);
        LOGI("[+] Записано %zu байт по адресу 0x%lX", size, address);
        return true;
    }

    // --------------------------------------------------
    // readFloat — читает float значение из памяти
    // УРОК: Так читаем HP, скорость, координаты
    // --------------------------------------------------
    static float readFloat(uintptr_t address) {
        if (!address) return 0.0f;
        return *reinterpret_cast<float*>(address);
    }

    // --------------------------------------------------
    // writeFloat — записывает float значение в память
    // УРОК: Так меняем HP, скорость игрока
    // --------------------------------------------------
    static bool writeFloat(uintptr_t address, float value) {
        if (!address) return false;
        *reinterpret_cast<float*>(address) = value;
        LOGI("[+] Записан float %.2f по адресу 0x%lX", value, address);
        return true;
    }

    // --------------------------------------------------
    // writeInt — записывает int значение
    // УРОК: Монеты, патроны, количество стрел
    // --------------------------------------------------
    static bool writeInt(uintptr_t address, int value) {
        if (!address) return false;
        *reinterpret_cast<int*>(address) = value;
        LOGI("[+] Записан int %d по адресу 0x%lX", value, address);
        return true;
    }
};
