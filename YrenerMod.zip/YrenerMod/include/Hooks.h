#pragma once
// ================================================
//  Hooks.h — Класс хуков для Bowmasters ARM64
//  Yrener Soft | Учебный мод
//
//  4 ФУНКЦИИ:
//  1. God Mode      — бессмертие
//  2. Rapid Fire    — 4-5 стрел за раз
//  3. Instant Kill  — мгновенное убийство
//  4. Aim Helper    — точные координаты хедшота
//
//  УРОК: Хук = перехват функции игры.
//  Игра думает что вызывает свою функцию,
//  но на самом деле вызывает НАШУ.
// ================================================

#include <cstdint>
#include <android/log.h>
#include "Memory.h"

// Dobby — библиотека для установки хуков на ARM64
// GitHub: jmpews/Dobby
#include "dobby.h"

#define TAG "YrenerSoft"

// ================================================
//  СМЕЩЕНИЯ ФУНКЦИЙ (offsets)
//  УРОК: Это адреса функций внутри libil2cpp.so
//  Найдены через анализ .so файла в IDA Pro / Ghidra
//  Для Bowmasters это ПРИМЕРНЫЕ значения —
//  точные нужно искать самому в своей версии APK!
//
//  Как искать: открываешь libil2cpp.so в Ghidra,
//  ищешь функцию по названию через global-metadata.dat
//  и смотришь её адрес минус базовый адрес = offset
// ================================================
#define OFFSET_TAKE_DAMAGE    0x00000000  // TakeDamage(float damage)
#define OFFSET_SHOOT_ARROW    0x00000000  // ShootArrow(Vector3 direction)
#define OFFSET_KILL_ENEMY     0x00000000  // KillEnemy(Enemy* target)
#define OFFSET_GET_AIM_ANGLE  0x00000000  // GetAimAngle() -> Vector2

// ================================================
//  СОСТОЯНИЯ ЧИТ-ФУНКЦИЙ
//  Эти переменные меню включает/выключает
// ================================================
namespace CheatState {
    bool godMode    = false;  // бессмертие вкл/выкл
    bool rapidFire  = false;  // мультистрел вкл/выкл
    bool instantKill= false;  // мгновенное убийство
    bool aimHelper  = false;  // помощник прицела
}

// ================================================
//  СТРУКТУРЫ ДАННЫХ ИГРЫ
//  УРОК: Так Unity хранит координаты и векторы
// ================================================
struct Vector2 {
    float x, y;
};

struct Vector3 {
    float x, y, z;
};

// ================================================
class Hooks {
public:

    // Указатели на оригинальные функции
    // УРОК: Сохраняем оригинал чтобы вызывать его
    //       когда чит выключен
    static void (*orig_TakeDamage)(void* self, float damage, void* method);
    static void (*orig_ShootArrow)(void* self, Vector3 dir, void* method);
    static void (*orig_KillEnemy) (void* self, void* enemy, void* method);
    static Vector2 (*orig_GetAimAngle)(void* self, void* method);

    // ============================================
    //  ХУК 1: GOD MODE — Бессмертие
    //
    //  УРОК: Игра вызывает TakeDamage каждый раз
    //  когда стрела попадает в игрока.
    //  Мы перехватываем этот вызов и если
    //  godMode включён — просто ничего не делаем.
    //  Игрок не получает урон = бессмертие!
    // ============================================
    static void hook_TakeDamage(void* self, float damage, void* method) {
        if (CheatState::godMode) {
            LOGI("[GodMode] Урон %.1f заблокирован!", damage);
            return; // ← не вызываем оригинал = нет урона
        }
        // Чит выключен — вызываем оригинальную функцию
        orig_TakeDamage(self, damage, method);
    }

    // ============================================
    //  ХУК 2: RAPID FIRE — 4-5 стрел за выстрел
    //
    //  УРОК: ShootArrow вызывается 1 раз = 1 стрела.
    //  Мы вызываем её 4-5 раз подряд с разными углами.
    //  Результат: веер из стрел при одном выстреле!
    // ============================================
    static void hook_ShootArrow(void* self, Vector3 dir, void* method) {
        if (CheatState::rapidFire) {
            LOGI("[RapidFire] Выпускаем 5 стрел!");

            // Выпускаем 5 стрел с небольшим разбросом
            // УРОК: dir — это направление полёта стрелы
            //       Меняем dir.x немного = разные углы
            float offsets[5] = { -0.08f, -0.04f, 0.0f, 0.04f, 0.08f };

            for (int i = 0; i < 5; i++) {
                Vector3 newDir = dir;
                newDir.x += offsets[i]; // немного меняем угол
                orig_ShootArrow(self, newDir, method);
            }
            return;
        }
        // Обычный выстрел
        orig_ShootArrow(self, dir, method);
    }

    // ============================================
    //  ХУК 3: INSTANT KILL — Мгновенное убийство
    //
    //  УРОК: Вместо того чтобы наносить урон,
    //  мы напрямую вызываем функцию смерти врага.
    //  KillEnemy() = противник сразу умирает!
    // ============================================
    static void hook_KillEnemy(void* self, void* enemy, void* method) {
        if (CheatState::instantKill) {
            LOGI("[InstantKill] Враг уничтожен мгновенно!");
            // Вызываем оригинал — убиваем врага как обычно
            // но урон уже максимальный (патчим в Memory)
            orig_KillEnemy(self, enemy, method);
            return;
        }
        orig_KillEnemy(self, enemy, method);
    }

    // ============================================
    //  ХУК 4: AIM HELPER — Точные координаты
    //
    //  УРОК: GetAimAngle() возвращает угол прицела.
    //  Мы перехватываем результат и корректируем
    //  его так, чтобы стрела летела точно в голову.
    //  Vector2.y = вертикальный угол (высота)
    //  Голова противника примерно на +15° выше центра
    // ============================================
    static Vector2 hook_GetAimAngle(void* self, void* method) {
        Vector2 angle = orig_GetAimAngle(self, method);

        if (CheatState::aimHelper) {
            // Корректируем угол вверх для хедшота
            // УРОК: +15.0f = поднимаем прицел на 15 градусов
            //       Это примерное значение! В реальности
            //       зависит от расстояния до врага
            angle.y += 15.0f;
            LOGI("[AimHelper] Угол скорректирован: X=%.2f Y=%.2f", angle.x, angle.y);
        }

        return angle;
    }

    // ============================================
    //  setupHooks — устанавливаем все хуки
    //  УРОК: Вызывается один раз при загрузке .so
    //        Dobby подменяет адреса функций в памяти
    // ============================================
    static void setupHooks(uintptr_t base) {
        LOGI("[*] Устанавливаем хуки...");

        // ХУК 1: God Mode
        if (OFFSET_TAKE_DAMAGE) {
            DobbyHook(
                (void*)(base + OFFSET_TAKE_DAMAGE),  // адрес в памяти
                (void*)hook_TakeDamage,               // наша функция
                (void**)&orig_TakeDamage              // сохраняем оригинал
            );
            LOGI("[+] GodMode хук установлен");
        }

        // ХУК 2: Rapid Fire
        if (OFFSET_SHOOT_ARROW) {
            DobbyHook(
                (void*)(base + OFFSET_SHOOT_ARROW),
                (void*)hook_ShootArrow,
                (void**)&orig_ShootArrow
            );
            LOGI("[+] RapidFire хук установлен");
        }

        // ХУК 3: Instant Kill
        if (OFFSET_KILL_ENEMY) {
            DobbyHook(
                (void*)(base + OFFSET_KILL_ENEMY),
                (void*)hook_KillEnemy,
                (void**)&orig_KillEnemy
            );
            LOGI("[+] InstantKill хук установлен");
        }

        // ХУК 4: Aim Helper
        if (OFFSET_GET_AIM_ANGLE) {
            DobbyHook(
                (void*)(base + OFFSET_GET_AIM_ANGLE),
                (void*)hook_GetAimAngle,
                (void**)&orig_GetAimAngle
            );
            LOGI("[+] AimHelper хук установлен");
        }

        LOGI("[*] Все хуки установлены успешно!");
    }
};

// Определяем статические указатели
void (*Hooks::orig_TakeDamage)(void*, float, void*) = nullptr;
void (*Hooks::orig_ShootArrow)(void*, Vector3, void*) = nullptr;
void (*Hooks::orig_KillEnemy)(void*, void*, void*) = nullptr;
Vector2 (*Hooks::orig_GetAimAngle)(void*, void*) = nullptr;
