#pragma once
// ================================================
//  Menu.h — Класс меню читов
//  Yrener Soft | Bowmasters ARM64
//
//  УРОК: Меню управляет состоянием читов.
//  В реальном моде здесь был бы ImGui или
//  Android Overlay. Сейчас — простое управление
//  через логику включения/выключения функций.
// ================================================

#include <android/log.h>
#include "Hooks.h"

#define TAG "YrenerSoft"

class Menu {
public:

    // ============================================
    //  Структура одного пункта меню
    //  УРОК: Каждая функция имеет:
    //  - name: название для отображения
    //  - enabled: вкл или выкл
    //  - toggle(): переключить состояние
    // ============================================
    struct MenuItem {
        const char* name;
        bool& enabled;        // ссылка на переменную состояния

        void toggle() {
            enabled = !enabled;
            __android_log_print(ANDROID_LOG_INFO, TAG,
                "[Menu] %s: %s", name, enabled ? "ВКЛ ✓" : "ВЫКЛ ✗");
        }

        bool isEnabled() const { return enabled; }
    };

    // ============================================
    //  Все пункты меню
    //  УРОК: Связываем пункты меню с переменными
    //        состояния из CheatState
    // ============================================
    MenuItem items[4] = {
        { "God Mode    | Бессмертие",       CheatState::godMode     },
        { "Rapid Fire  | 5 стрел сразу",    CheatState::rapidFire   },
        { "Instant Kill| Мгновенное убийство", CheatState::instantKill },
        { "Aim Helper  | Точный прицел",    CheatState::aimHelper   }
    };

    static const int ITEM_COUNT = 4;

    // ============================================
    //  printStatus — выводит состояние всех читов
    //  УРОК: В Android логи смотришь через:
    //        adb logcat | grep YrenerSoft
    // ============================================
    void printStatus() {
        __android_log_print(ANDROID_LOG_INFO, TAG,
            "╔══════════════════════════════╗");
        __android_log_print(ANDROID_LOG_INFO, TAG,
            "║     YRENER SOFT — MENU       ║");
        __android_log_print(ANDROID_LOG_INFO, TAG,
            "║    Bowmasters ARM64 Mod      ║");
        __android_log_print(ANDROID_LOG_INFO, TAG,
            "╠══════════════════════════════╣");

        for (int i = 0; i < ITEM_COUNT; i++) {
            __android_log_print(ANDROID_LOG_INFO, TAG,
                "║ [%s] %s",
                items[i].isEnabled() ? "✓" : " ",
                items[i].name);
        }

        __android_log_print(ANDROID_LOG_INFO, TAG,
            "╚══════════════════════════════╝");
    }

    // ============================================
    //  enableAll / disableAll — для теста
    // ============================================
    void enableAll() {
        for (int i = 0; i < ITEM_COUNT; i++) {
            items[i].enabled = true;
        }
        LOGI("[Menu] Все читы включены!");
        printStatus();
    }

    void disableAll() {
        for (int i = 0; i < ITEM_COUNT; i++) {
            items[i].enabled = false;
        }
        LOGI("[Menu] Все читы выключены!");
    }

    // ============================================
    //  toggle — переключить конкретный чит по индексу
    //  УРОК: 0=GodMode, 1=RapidFire, 2=InstantKill,
    //        3=AimHelper
    // ============================================
    void toggle(int index) {
        if (index < 0 || index >= ITEM_COUNT) return;
        items[index].toggle();
        printStatus();
    }
};
