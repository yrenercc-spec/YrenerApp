# 🎯 YRENER SOFT — Bowmasters ARM64 Mod
## Учебный мод | Урок по C++ и Android хукам

---

## 📁 Структура проекта

```
YrenerMod/
├── include/
│   ├── Memory.h      ← Класс работы с памятью
│   ├── Hooks.h       ← Класс хуков (4 функции)
│   └── Menu.h        ← Класс меню читов
├── src/
│   └── main.cpp      ← Точка входа JNI_OnLoad
├── libs/
│   ├── Dobby/        ← Библиотека для хуков (скачать)
│   └── KittyMemory/  ← Библиотека памяти (скачать)
└── CMakeLists.txt    ← Файл сборки
```

---

## 🧠 Как это работает (кратко)

```
APK запускается
    ↓
Android грузит libil2cpp.so (игра)
    ↓
Android грузит libYrenerMod.so (наш мод)
    ↓
JNI_OnLoad() вызывается автоматически
    ↓
Мы ждём пока libil2cpp.so загрузится
    ↓
Находим базовый адрес (base)
    ↓
base + offset = реальный адрес функции
    ↓
Dobby подменяет функцию на нашу (хук)
    ↓
Читы работают!
```

---

## 🔍 Как найти OFFSET (смещение) функции

Это самый важный шаг! Без правильных offset'ов хуки не работают.

### Шаг 1 — Достать libil2cpp.so из APK
```bash
# Через MT Manager:
# Открыть APK → lib → arm64-v8a → скопировать libil2cpp.so

# Или через Termux:
cd /data/app/com.playgendary.bowmasters*/base.apk
unzip base.apk lib/arm64-v8a/libil2cpp.so
```

### Шаг 2 — Достать global-metadata.dat
```bash
# Этот файл содержит имена всех функций!
# Путь внутри APK:
# assets/bin/Data/Managed/Metadata/global-metadata.dat
```

### Шаг 3 — Открыть в Ghidra (на ПК)
```
1. Скачать Ghidra: https://ghidra-sre.org
2. Создать новый проект
3. Импортировать libil2cpp.so
4. Запустить Il2CppDumper для восстановления имён
5. Искать функции: TakeDamage, ShootArrow и т.д.
```

### Шаг 4 — Найти offset
```
Реальный адрес в Ghidra: 0x7F1234ABCD
Базовый адрес (base):    0x7F12000000
                         ─────────────
Offset =                       0x34ABCD  ← вот это вставляем в Hooks.h!
```

---

## 🛠️ Как собрать через Termux

```bash
# 1. Установить нужные пакеты
pkg update && pkg upgrade
pkg install cmake git wget

# 2. Скачать Android NDK
wget https://dl.google.com/android/repository/android-ndk-r25c-linux.zip
unzip android-ndk-r25c-linux.zip

# 3. Скачать Dobby
git clone https://github.com/jmpews/Dobby

# 4. Собрать проект
mkdir build && cd build
cmake .. \
  -DCMAKE_TOOLCHAIN_FILE=$NDK/build/cmake/android.toolchain.cmake \
  -DANDROID_ABI=arm64-v8a \
  -DANDROID_PLATFORM=android-21
make

# 5. Результат: libYrenerMod.so
```

---

## 📦 Как инжектировать .so в игру

```bash
# Способ 1 — Через перепаковку APK (MT Manager):
# 1. Открыть APK в MT Manager
# 2. Перейти в lib/arm64-v8a/
# 3. Добавить libYrenerMod.so
# 4. Открыть AndroidManifest.xml
# 5. Подписать APK → установить

# Способ 2 — Через Zygisk (нужен Root):
# Собрать как Zygisk модуль
```

---

## 📊 4 Функции мода

| # | Название | Что делает | Хук |
|---|---|---|---|
| 1 | **God Mode** | Блокирует урон по игроку | TakeDamage() |
| 2 | **Rapid Fire** | 5 стрел вместо 1 | ShootArrow() |
| 3 | **Instant Kill** | Враг умирает мгновенно | KillEnemy() |
| 4 | **Aim Helper** | Корректирует угол для хедшота | GetAimAngle() |

---

## ⚠️ Важно

- Offsets нужно найти самому для своей версии игры
- При обновлении игры offsets меняются — нужно искать заново
- Это учебный проект для изучения C++ и Android NDK
- Тестируй только в оффлайн режиме!

---

## 📚 Что изучить дальше

1. **ARM64 Assembly** — понять что делает код в Ghidra
2. **IL2CPP Dumper** — восстанавливать имена Unity функций
3. **ImGui для Android** — сделать графическое меню
4. **Zygisk** — профессиональный инжект без перепаковки

---

*Yrener Soft | Для учебных целей*
