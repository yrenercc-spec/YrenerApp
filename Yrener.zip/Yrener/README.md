# 🎯 Yrener Soft — Bowmasters ARM64
### tg: @Yrener_Soft

---

## 📁 Структура

```
Yrener/
├── include/
│   ├── Memory.h      ← чтение/запись памяти
│   ├── AimHelper.h   ← вычисление угла хедшота
│   ├── Hooks.h       ← 5 хуков (все функции)
│   └── Menu.h        ← управление читами
├── src/
│   └── main.cpp      ← точка входа JNI_OnLoad
├── libs/
│   └── Dobby/        ← создаётся при сборке автоматически
├── CMakeLists.txt
└── .github/
    └── workflows/
        └── main.yml  ← GitHub Actions (сборка)
```

---

## ⚙️ 5 Функций

| # | Функция | Описание |
|---|---------|----------|
| 1 | **God Mode** | Блокирует любой урон |
| 2 | **Rapid Fire** | 5 стрел за 1 выстрел (веер) |
| 3 | **Instant Kill** | Враг умирает мгновенно |
| 4 | **Aim Helper** | Вычисляет точный угол для хедшота |
| 5 | **Auto Shoot** | Авто прицел + выстрел в голову |

---

## 🔍 КАК НАЙТИ OFFSETS (ОБЯЗАТЕЛЬНО!)

Без offset'ов хуки не работают. Вот как их найти:

### Шаг 1 — Достань файлы из APK
```
MT Manager → открой Bowmasters.apk
→ lib/arm64-v8a/libil2cpp.so → скопируй
→ assets/bin/Data/Managed/Metadata/global-metadata.dat → скопируй
```

### Шаг 2 — Il2CppDumper (восстановить имена)
```
Скачай: https://github.com/Perfare/Il2CppDumper
Запусти: Il2CppDumper.exe libil2cpp.so global-metadata.dat
Получишь: dump.cs + script.json — в них все имена функций!
```

### Шаг 3 — Ghidra (найти адреса)
```
1. Скачай Ghidra: https://ghidra-sre.org
2. Импортируй libil2cpp.so
3. Запусти il2cpp.py скрипт (из Il2CppDumper/ghidra_with_struct.py)
4. Ищи функции: TakeDamage, ShootArrow, KillEnemy и т.д.
5. Смотри адрес функции в Ghidra
```

### Шаг 4 — Вычисли offset
```
Адрес в Ghidra:  0x007F1234ABCD
Базовый адрес:  -0x007F12000000
                ──────────────
Offset =              0x0034ABCD  ← вставляй в Hooks.h!
```

### Шаг 5 — Вставь в Hooks.h
```cpp
#define OFFSET_TAKE_DAMAGE    0x34ABCD  // ← твой offset
#define OFFSET_SHOOT_ARROW    0x56EF12
#define OFFSET_KILL_ENEMY     0x789ABC
#define OFFSET_GET_AIM_ANGLE  0x9ABCDE
#define OFFSET_GET_POSITION   0xBCDEF0
```

---

## 🚀 Сборка через GitHub Actions

1. Создай репозиторий на GitHub
2. Загрузи все файлы
3. Зайди в Actions → Build Yrener ARM64 → Run workflow
4. После сборки скачай артефакт `libYrenerMod-arm64`

---

## 📦 Инжект через MT Manager

```
1. Открой APK Bowmasters в MT Manager
2. Перейди в lib/arm64-v8a/
3. Добавь libYrenerMod.so
4. Подпиши APK (MT Manager → Sign)
5. Установи и запусти!
```

---

## 📊 Логи (проверка работы)

```bash
# Подключи телефон к ПК через USB и смотри логи:
adb logcat | grep -E "Yrener|YrenerHook|YrenerAim"

# Должно появиться:
# [+] libil2cpp.so найден: 0x...
# [+] TakeDamage хук установлен
# [AimHelper] Угол скорректирован → 17.3°
```

---

*Yrener Soft | Учебный проект | tg: @Yrener_Soft*
