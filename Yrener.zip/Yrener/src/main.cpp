// ================================================
//  main.cpp — Точка входа Yrener Soft
//  Bowmasters ARM64
// ================================================
#include <jni.h>
#include <pthread.h>
#include <unistd.h>
#include <android/log.h>
#include "Memory.h"
#include "Hooks.h"
#include "Menu.h"

#define TAG "YrenerMain"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

Menu g_menu;

void* modThread(void*) {
    LOGI("╔══════════════════════════════╗");
    LOGI("║   YRENER SOFT ЗАПУЩЕН        ║");
    LOGI("║   Bowmasters ARM64 v1.0      ║");
    LOGI("║   tg: @Yrener_Soft           ║");
    LOGI("╚══════════════════════════════╝");

    // Ждём пока libil2cpp.so появится в памяти
    uintptr_t base = 0;
    LOGI("[*] Ожидание libil2cpp.so...");
    while (!base) {
        base = Memory::getLibBase("libil2cpp.so");
        if (!base) sleep(1);
    }
    LOGI("[+] libil2cpp.so найден: 0x%lX", base);

    // Даём игре время инициализироваться
    sleep(3);

    // Устанавливаем хуки
    Hooks::setupHooks(base);

    // Показываем статус меню
    g_menu.printStatus();

    return nullptr;
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved) {
    LOGI("[*] JNI_OnLoad → запускаем мод...");
    pthread_t t;
    pthread_create(&t, nullptr, modThread, nullptr);
    pthread_detach(t);
    return JNI_VERSION_1_6;
}
