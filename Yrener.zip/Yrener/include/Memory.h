#pragma once
// ================================================
//  Memory.h — Работа с памятью игры
//  Yrener Soft | Bowmasters ARM64
// ================================================
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <android/log.h>

#define TAG_MEM "YrenerMem"

class Memory {
public:
    // Найти базовый адрес .so библиотеки
    static uintptr_t getLibBase(const char* libName) {
        FILE* maps = fopen("/proc/self/maps", "r");
        if (!maps) return 0;
        char line[512];
        uintptr_t base = 0;
        while (fgets(line, sizeof(line), maps)) {
            if (strstr(line, libName) && strstr(line, "r-xp")) {
                base = (uintptr_t)strtoull(line, nullptr, 16);
                break;
            }
        }
        fclose(maps);
        if (base)
            __android_log_print(ANDROID_LOG_INFO, TAG_MEM, "[+] %s base: 0x%lX", libName, base);
        return base;
    }

    static float readFloat(uintptr_t addr) {
        if (!addr) return 0.f;
        return *reinterpret_cast<float*>(addr);
    }

    static bool writeFloat(uintptr_t addr, float val) {
        if (!addr) return false;
        *reinterpret_cast<float*>(addr) = val;
        return true;
    }

    static bool writeInt(uintptr_t addr, int val) {
        if (!addr) return false;
        *reinterpret_cast<int*>(addr) = val;
        return true;
    }

    // Патч байтов (NOP и т.д.)
    static bool writeBytes(uintptr_t addr, const uint8_t* bytes, size_t len) {
        if (!addr) return false;
        memcpy(reinterpret_cast<void*>(addr), bytes, len);
        return true;
    }
};
