#pragma once
// ================================================
//  AimHelper.h — Динамическое вычисление хедшота
//  Yrener Soft | Bowmasters ARM64
//
//  ВАЖНО: Враг двигается! Угол пересчитывается
//  КАЖДЫЙ КАДР на основе ТЕКУЩИХ координат врага.
//
//  Как работает:
//  1. hook_GetPosition() обновляет позиции каждый кадр
//  2. calcDynamicAngle() считает угол по актуальным данным
//  3. Предсказываем где враг БУДЕТ когда стрела долетит
//  4. hook_GetAimAngle() подставляет свежий угол
// ================================================
#include <cmath>
#include <android/log.h>

#define TAG_AIM "YrenerAim"
#define M_PIf   3.14159265358979323846f

struct Vector2 { float x, y; };
struct Vector3 { float x, y, z; };

namespace BowPhysics {
    constexpr float GRAVITY      = 9.81f;
    constexpr float MAX_VELOCITY = 55.0f;
    constexpr float HEAD_OFFSET  = 0.75f;  // высота головы над центром
}

class DynamicTracker {
public:
    Vector3 playerPos = {0.f, 0.f, 0.f};
    Vector3 enemyPos  = {5.f, 0.f, 0.f};
    Vector3 enemyVel  = {0.f, 0.f, 0.f};  // скорость врага
    Vector3 prevEnemy = {5.f, 0.f, 0.f};
    float   lastAngle = 0.f;

    // Обновляем позицию врага и считаем его скорость
    // Вызывается КАЖДЫЙ КАДР из hook_GetPosition
    void updateEnemy(Vector3 newPos) {
        enemyVel.x = newPos.x - prevEnemy.x;
        enemyVel.y = newPos.y - prevEnemy.y;
        enemyVel.z = newPos.z - prevEnemy.z;
        prevEnemy  = enemyPos;
        enemyPos   = newPos;
    }

    void updatePlayer(Vector3 newPos) {
        playerPos = newPos;
    }

    // Предсказываем где враг будет через tFlight секунд
    Vector3 predictEnemyPos(float tFlight) {
        return {
            enemyPos.x + enemyVel.x * tFlight,
            enemyPos.y + enemyVel.y * tFlight,
            enemyPos.z + enemyVel.z * tFlight
        };
    }

    // Время полёта стрелы до цели
    float calcFlightTime(float distX, float velocity, float angle_rad) {
        float vx = velocity * cosf(angle_rad);
        return (vx > 0.001f) ? distX / vx : 1.0f;
    }

    // ==========================================
    //  calcDynamicAngle — главная функция
    //
    //  Считает угол КАЖДЫЙ РАЗ заново с учётом
    //  текущей позиции и скорости врага.
    //
    //  4 итерации уточнения:
    //  → считаем угол → считаем время полёта
    //  → предсказываем позицию врага
    //  → пересчитываем угол на новую позицию
    //  → повторяем для точности
    // ==========================================
    float calcDynamicAngle(float power) {
        float v = (power / 100.0f) * BowPhysics::MAX_VELOCITY;
        float g = BowPhysics::GRAVITY;
        if (v < 1.0f) v = BowPhysics::MAX_VELOCITY;

        float dx = fabsf(enemyPos.x - playerPos.x);
        float dy = (enemyPos.y - playerPos.y) + BowPhysics::HEAD_OFFSET;
        if (dx < 0.1f) dx = 0.1f;

        float angle = 15.0f * (M_PIf / 180.0f);

        for (int i = 0; i < 4; i++) {
            // Время полёта при текущем угле
            float t = calcFlightTime(dx, v, angle);

            // Предсказанная позиция врага
            Vector3 pred = predictEnemyPos(t);
            float px = fabsf(pred.x - playerPos.x);
            float py = (pred.y - playerPos.y) + BowPhysics::HEAD_OFFSET;
            if (px < 0.1f) px = 0.1f;

            // Формула угла для параболического броска
            float v2   = v * v;
            float disc = v2*v2 - g*(g*px*px + 2.0f*py*v2);

            if (disc < 0.f) {
                angle = 45.0f * (M_PIf / 180.0f);
                break;
            }
            angle = atanf((v2 - sqrtf(disc)) / (g * px));
            dx = px; dy = py;
        }

        lastAngle = angle * (180.0f / M_PIf);

        __android_log_print(ANDROID_LOG_INFO, TAG_AIM,
            "[DynAim] enemyX=%.2f vel=(%.3f,%.3f) power=%.0f%% → %.1f°",
            enemyPos.x, enemyVel.x, enemyVel.y, power, lastAngle);

        return lastAngle;
    }
};

inline DynamicTracker g_tracker;
