#pragma once
// ================================================
//  Hooks.h — Хуки для Bowmasters ARM64
//  Yrener Soft
//
//  5 ФУНКЦИЙ:
//  1. God Mode      — бессмертие
//  2. Rapid Fire    — 5 стрел сразу
//  3. Instant Kill  — мгновенное убийство
//  4. Aim Helper    — ДИНАМИЧЕСКИЙ угол хедшота
//                     пересчитывается каждый кадр!
//  5. Auto Shoot    — авто выстрел в голову
//
//  ⚠️ OFFSETS нужно найти через Ghidra + Il2CppDumper
//     Смотри README.md как их искать
// ================================================
#include <cstdint>
#include <cmath>
#include <android/log.h>
#include "Memory.h"
#include "AimHelper.h"
#include "dobby.h"

#define TAG_HOOK "YrenerHook"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG_HOOK, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG_HOOK, __VA_ARGS__)

// ================================================
//  OFFSETS — вставь свои значения из Ghidra!
// ================================================
#define OFFSET_TAKE_DAMAGE    0x0
#define OFFSET_SHOOT_ARROW    0x0
#define OFFSET_KILL_ENEMY     0x0
#define OFFSET_GET_AIM_ANGLE  0x0
#define OFFSET_GET_POSITION   0x0  // ← ключевой! обновляет позиции каждый кадр

// ================================================
//  Состояния читов
// ================================================
namespace CheatState {
    bool godMode     = false;
    bool rapidFire   = false;
    bool instantKill = false;
    bool aimHelper   = false;
    bool autoShoot   = false;

    // Текущая сила выстрела (берём из игры динамически)
    float currentPower = 100.0f;
}

// ================================================
class Hooks {
public:

    static void    (*orig_TakeDamage)  (void* self, float dmg, void* method);
    static void    (*orig_ShootArrow)  (void* self, Vector3 dir, float power, void* method);
    static void    (*orig_KillEnemy)   (void* self, void* enemy, void* method);
    static Vector2 (*orig_GetAimAngle) (void* self, void* method);
    static Vector3 (*orig_GetPosition) (void* self, void* method);

    // Счётчик для определения кто игрок, кто враг
    static int s_posCallIdx;

    // ============================================
    //  ХУК 1: GOD MODE
    // ============================================
    static void hook_TakeDamage(void* self, float dmg, void* method) {
        if (CheatState::godMode) {
            LOGI("[GodMode] Урон %.1f заблокирован!", dmg);
            return;
        }
        orig_TakeDamage(self, dmg, method);
    }

    // ============================================
    //  ХУК 2: RAPID FIRE — 5 стрел с веером
    // ============================================
    static void hook_ShootArrow(void* self, Vector3 dir, float power, void* method) {
        // Сохраняем текущую силу для AimHelper
        CheatState::currentPower = power;

        if (CheatState::rapidFire) {
            LOGI("[RapidFire] 5 стрел! (power=%.0f%%)", power);
            const float spread[5] = { -0.10f, -0.05f, 0.0f, 0.05f, 0.10f };
            for (int i = 0; i < 5; i++) {
                Vector3 d = dir;
                d.x += spread[i];
                // Нормализуем вектор
                float len = sqrtf(d.x*d.x + d.y*d.y + d.z*d.z);
                if (len > 0.001f) { d.x /= len; d.y /= len; d.z /= len; }
                orig_ShootArrow(self, d, power, method);
            }
            return;
        }

        if (CheatState::autoShoot) {
            // Динамический угол на текущую позицию врага
            float angleDeg = g_tracker.calcDynamicAngle(power);
            float angleRad = angleDeg * (M_PIf / 180.0f);

            // Определяем направление (враг слева или справа)
            float sign = (g_tracker.enemyPos.x > g_tracker.playerPos.x) ? 1.0f : -1.0f;
            dir.x = cosf(angleRad) * sign;
            dir.y = sinf(angleRad);
            dir.z = 0.0f;

            LOGI("[AutoShoot] Выстрел! угол=%.1f° dir=(%.2f,%.2f)", angleDeg, dir.x, dir.y);
            orig_ShootArrow(self, dir, power, method);
            return;
        }

        orig_ShootArrow(self, dir, power, method);
    }

    // ============================================
    //  ХУК 3: INSTANT KILL
    // ============================================
    static void hook_KillEnemy(void* self, void* enemy, void* method) {
        if (CheatState::instantKill && enemy) {
            LOGI("[InstantKill] Мгновенное убийство!");
        }
        orig_KillEnemy(self, enemy, method);
    }

    // ============================================
    //  ХУК 4: AIM HELPER — ДИНАМИЧЕСКИЙ
    //
    //  Каждый раз когда игра запрашивает угол
    //  прицела — мы пересчитываем его заново
    //  на основе ТЕКУЩЕЙ позиции врага.
    //
    //  Враг сдвинулся на 0.1 юнита → угол изменился
    //  Враг прыгнул вверх → угол изменился
    //  Всё автоматически, каждый кадр!
    // ============================================
    static Vector2 hook_GetAimAngle(void* self, void* method) {
        Vector2 angle = orig_GetAimAngle(self, method);

        if (CheatState::aimHelper || CheatState::autoShoot) {
            // Пересчитываем угол на ТЕКУЩИЕ координаты врага
            float dynAngle = g_tracker.calcDynamicAngle(CheatState::currentPower);

            // Подменяем угол прицела
            angle.y = dynAngle;
        }

        return angle;
    }

    // ============================================
    //  ХУК 5: GET POSITION — КЛЮЧЕВОЙ ХУК
    //
    //  Этот хук вызывается КАЖДЫЙ КАДР игрой.
    //  Каждый кадр мы обновляем позиции игрока
    //  и врага в g_tracker.
    //
    //  Именно отсюда AimHelper знает где враг
    //  СЕЙЧАС (не секунду назад, а прямо сейчас).
    //
    //  Как различаем игрока и врага:
    //  В Bowmasters 2 персонажа.
    //  Первый вызов GetPosition в кадре = игрок
    //  Второй вызов = враг
    //  (это упрощение, может потребовать настройки)
    // ============================================
    static Vector3 hook_GetPosition(void* self, void* method) {
        Vector3 pos = orig_GetPosition(self, method);

        s_posCallIdx++;

        if (s_posCallIdx % 2 == 1) {
            // Нечётный вызов = игрок
            g_tracker.updatePlayer(pos);
        } else {
            // Чётный вызов = враг
            // updateEnemy считает скорость врага автоматически!
            g_tracker.updateEnemy(pos);
        }

        return pos;
    }

    // ============================================
    //  setupHooks
    // ============================================
    static void setupHooks(uintptr_t base) {
        LOGI("╔══════════════════════════════╗");
        LOGI("║  Yrener Soft v1.0 — Hooks    ║");
        LOGI("╚══════════════════════════════╝");

        struct Entry {
            const char* name;
            uintptr_t   offset;
            void*       hookFn;
            void**      origFn;
        };

        Entry entries[] = {
            { "TakeDamage",  OFFSET_TAKE_DAMAGE,   (void*)hook_TakeDamage,  (void**)&orig_TakeDamage  },
            { "ShootArrow",  OFFSET_SHOOT_ARROW,   (void*)hook_ShootArrow,  (void**)&orig_ShootArrow  },
            { "KillEnemy",   OFFSET_KILL_ENEMY,    (void*)hook_KillEnemy,   (void**)&orig_KillEnemy   },
            { "GetAimAngle", OFFSET_GET_AIM_ANGLE, (void*)hook_GetAimAngle, (void**)&orig_GetAimAngle },
            { "GetPosition", OFFSET_GET_POSITION,  (void*)hook_GetPosition, (void**)&orig_GetPosition },
        };

        for (auto& e : entries) {
            if (e.offset == 0x0) {
                LOGE("[-] %s: offset не задан! Ищи в Ghidra.", e.name);
                continue;
            }
            int r = DobbyHook((void*)(base + e.offset), e.hookFn, e.origFn);
            if (r == 0)
                LOGI("[+] %s хук ОК (0x%lX)", e.name, e.offset);
            else
                LOGE("[-] %s ошибка хука: %d", e.name, r);
        }
        LOGI("[✓] Все хуки установлены!");
    }
};

void    (*Hooks::orig_TakeDamage)  (void*, float, void*)          = nullptr;
void    (*Hooks::orig_ShootArrow)  (void*, Vector3, float, void*) = nullptr;
void    (*Hooks::orig_KillEnemy)   (void*, void*, void*)          = nullptr;
Vector2 (*Hooks::orig_GetAimAngle) (void*, void*)                 = nullptr;
Vector3 (*Hooks::orig_GetPosition) (void*, void*)                 = nullptr;
int     Hooks::s_posCallIdx                                        = 0;
