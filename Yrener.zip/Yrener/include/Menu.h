#pragma once
// ================================================
//  Menu.h — Управление состоянием читов
//  Yrener Soft | Bowmasters ARM64
// ================================================
#include <android/log.h>
#include "Hooks.h"

#define TAG_MENU "YrenerMenu"

class Menu {
public:
    struct Item {
        const char* name;
        bool&       state;
        void toggle() {
            state = !state;
            __android_log_print(ANDROID_LOG_INFO, TAG_MENU,
                "[%s] %s", state ? "ВКЛ ✓" : "ВЫКЛ", name);
        }
    };

    Item items[5] = {
        { "God Mode    | Бессмертие",          CheatState::godMode     },
        { "Rapid Fire  | 5 стрел сразу",       CheatState::rapidFire   },
        { "Instant Kill| Мгновенное убийство", CheatState::instantKill },
        { "Aim Helper  | Точный угол хедшота", CheatState::aimHelper   },
        { "Auto Shoot  | Авто выстрел в голову",CheatState::autoShoot  },
    };

    static constexpr int COUNT = 5;

    void printStatus() {
        __android_log_print(ANDROID_LOG_INFO, TAG_MENU, "╔══════════════════════════════════╗");
        __android_log_print(ANDROID_LOG_INFO, TAG_MENU, "║      YRENER SOFT v1.0            ║");
        __android_log_print(ANDROID_LOG_INFO, TAG_MENU, "╠══════════════════════════════════╣");
        for (int i = 0; i < COUNT; i++) {
            __android_log_print(ANDROID_LOG_INFO, TAG_MENU,
                "║ [%s] %s",
                items[i].state ? "✓" : " ", items[i].name);
        }
        __android_log_print(ANDROID_LOG_INFO, TAG_MENU, "╚══════════════════════════════════╝");
    }

    void toggle(int idx) {
        if (idx >= 0 && idx < COUNT) {
            items[idx].toggle();
            printStatus();
        }
    }

    void enableAll() {
        for (int i = 0; i < COUNT; i++) items[i].state = true;
        printStatus();
    }
};
